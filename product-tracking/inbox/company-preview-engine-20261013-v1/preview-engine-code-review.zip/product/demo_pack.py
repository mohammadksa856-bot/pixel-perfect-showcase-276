"""Build the product demo pack from the real read-only HTTP API.

The pack is what the website preview and bot demos consume.  It is produced by
starting ``finengine.api.create_api_server`` on a *copy* of a local database and
requesting the public routes exactly as an external consumer would, so every
byte in the pack has passed the API's authentication and public-payload filter.
Nothing is computed, filled or corrected here: a missing company is stored as
the API's own 404 body, and missing sections stay missing.

Usage (from the repository root)::

    PYTHONPATH=src python product/demo_pack.py --db tmp/demo_copy.sqlite3 --out product/demo

The source database is opened by the API in read-only query mode; this script
never writes to it.  Never point --db at a production database.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import secrets
import subprocess
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from finengine.api import create_api_server
from finengine.api_contract import API_CONTRACT_VERSION

ROOT = Path(__file__).resolve().parents[1]

# Representative issuers for B07 acceptance: integrated energy, bank, insurer.
DEMO_COMPANIES = (
    ("SA", "2222", "ordinary_issuer"),
    ("SA", "1120", "bank"),
    ("SA", "8010", "insurer"),
)
ROUTES = ("page",)
CONTRACT_HEADER = "X-Marefa-API-Contract"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _git_head() -> str:
    try:
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True,
                              text=True, check=True).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return "unknown"


def _get(port: int, key: str, path: str) -> tuple[int, dict, str | None]:
    request = Request(f"http://127.0.0.1:{port}{path}", headers={"X-API-Key": key})
    try:
        with urlopen(request, timeout=60) as response:
            return (response.status, json.loads(response.read().decode("utf-8")),
                    response.headers.get(CONTRACT_HEADER))
    except HTTPError as error:
        return error.code, json.loads(error.read().decode("utf-8")), error.headers.get(CONTRACT_HEADER)


def build(db: Path, out: Path, companies=DEMO_COMPANIES, origin: Path | None = None) -> dict:
    source_hash_before = _sha256(db)
    key = secrets.token_hex(16)
    server = create_api_server(str(db), "127.0.0.1", 0, key)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    entries = []
    try:
        port = server.server_address[1]
        out.mkdir(parents=True, exist_ok=True)
        for market, symbol, archetype in companies:
            for route in ROUTES:
                status, body, contract = _get(port, key, f"/v1/companies/{market}/{symbol}/{route}")
                if contract != API_CONTRACT_VERSION:
                    raise RuntimeError(f"{route} for {market}:{symbol} answered API contract {contract!r}, "
                                       f"expected {API_CONTRACT_VERSION}")
                name = f"{market.lower()}-{symbol}-{route}.json"
                (out / name).write_text(json.dumps(body, ensure_ascii=False, indent=1) + "\n",
                                        encoding="utf-8", newline="\n")
                entries.append({"market": market, "symbol": symbol, "archetype": archetype,
                                "route": f"/v1/companies/{market}/{symbol}/{route}",
                                "http_status": status, "file": name, "api_contract": contract,
                                "contract_version": body.get("contract_version")})
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)
    source_hash_after = _sha256(db)
    if source_hash_after != source_hash_before:
        raise RuntimeError("source database changed while building the demo pack")
    manifest = {
        "artifact": "product_demo_pack",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "engine_commit": _git_head(),
        "api_contract_version": API_CONTRACT_VERSION,
        "source_database_sha256": source_hash_before,
        # The copy is opened by finengine.database.Database, which migrates its
        # schema; the untouched original is identified separately.
        "origin_database_sha256": _sha256(origin) if origin else None,
        "nature": ("Real API responses from a local copy of the development database. Not production, "
                   "not certified: factory readiness and understanding are reported by the API itself."),
        "entries": entries,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1) + "\n",
                                       encoding="utf-8", newline="\n")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--db", required=True, type=Path)
    parser.add_argument("--out", default=ROOT / "product" / "demo", type=Path)
    parser.add_argument("--origin", type=Path, help="original database the copy was made from (read only)")
    args = parser.parse_args()
    manifest = build(args.db, args.out, origin=args.origin)
    for entry in manifest["entries"]:
        print(entry["http_status"], entry["route"], entry["file"])


if __name__ == "__main__":
    main()
