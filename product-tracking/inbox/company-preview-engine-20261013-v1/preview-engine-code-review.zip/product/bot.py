"""Product bot commands built only on the public company-page contract (v5).

New commands answer from ``FinancialQueryService.company_page`` -- the same
payload ``/v1/companies/{m}/{s}/page`` serves -- and never compute, fill or
correct a value.  Every figure carries its period and source; every gap carries
the API's own reason; a value whose unit contradicts its meaning is withheld and
reported.  Any other command is delegated unchanged to
``finengine.telegram.answer_command``.

    /topics  SA 2222             the 18 investor topics and their state
    /fin     SA 2222 [fy|quarter|instant]   headline statement lines
    /missing SA 2222             what is unavailable and why, plus withheld values
    /sources SA 2222             archived official sources behind the figures
"""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

from finengine.query import FinancialQueryService
from finengine.telegram import HELP as ENGINE_HELP
from finengine.telegram import answer_command as engine_answer

from product.investor_topics import assess, load_contract_gaps

HELP = ENGINE_HELP + """
/topics SA 2222
/fin SA 2222 fy|quarter|instant
/missing SA 2222
/sources SA 2222"""

SUPPORTED_CONTRACT_VERSION = 5
NOT_COVERED = "هذه الشركة غير مغطاة في محرك البيانات بعد. لا نعرض لها أي رقم بديل."
READINESS_NOTE = "⚠️ لم تُقيَّم جاهزية بيانات هذه الشركة بعد؛ الأرقام كما نُشرت مع مصدرها وفترتها."

KIND_SNAPSHOT = {"fy": "annual", "quarter": "quarter", "instant": "instant"}
KIND_AR = {"fy": "سنة مالية", "quarter": "ربع", "instant": "في تاريخ", "ytd": "منذ بداية السنة", "ttm": "آخر 12 شهرًا"}
STATE_MARK = {"available": "✅", "partial": "◐", "unavailable": "✖", "not_in_contract": "—"}
STATE_AR = {"available": "متوفر", "partial": "جزئي", "unavailable": "غير متوفر",
            "not_in_contract": "خارج نطاق المصادر الحالية"}

# Headline lines per period kind, in statement order.  Banks report under
# banking_* keys; a key the company does not report is simply skipped.
FIN_LINES = {
    "fy": ("revenue", "total_operating_income", "net_financing_income", "operating_income", "ebitda",
           "net_income", "net_income_parent", "basic_eps", "eps_diluted", "operating_cash_flow", "capex",
           "free_cash_flow", "dividends_per_share", "return_on_equity", "net_margin"),
    "quarter": ("revenue", "total_operating_income", "operating_income", "net_income", "net_income_parent",
                "basic_eps", "eps_diluted", "operating_cash_flow", "free_cash_flow"),
    "instant": ("total_assets", "total_liabilities", "total_equity", "equity_parent", "cash_equivalents",
                "total_debt", "net_debt", "gross_loans", "customer_deposits"),
}
LABEL_AR = {
    "revenue": "الإيرادات", "total_operating_income": "إجمالي دخل العمليات",
    "net_financing_income": "صافي دخل التمويل", "operating_income": "الدخل التشغيلي", "ebitda": "EBITDA",
    "net_income": "صافي الدخل", "net_income_parent": "صافي الدخل لمساهمي الشركة",
    "basic_eps": "ربحية السهم الأساسية", "eps_diluted": "ربحية السهم المخفضة",
    "operating_cash_flow": "التدفق النقدي التشغيلي", "capex": "الإنفاق الرأسمالي",
    "free_cash_flow": "التدفق النقدي الحر", "dividends_per_share": "التوزيع لكل سهم",
    "return_on_equity": "العائد على حقوق الملكية", "net_margin": "صافي الهامش",
    "total_assets": "إجمالي الأصول", "total_liabilities": "إجمالي المطلوبات",
    "total_equity": "إجمالي حقوق الملكية", "equity_parent": "حقوق مساهمي الشركة",
    "cash_equivalents": "النقد وما في حكمه", "total_debt": "إجمالي الدين", "net_debt": "صافي الدين",
    "gross_loans": "إجمالي التمويل", "customer_deposits": "ودائع العملاء",
}
REASON_AR = {
    "licensed_consensus_feed_required": "يتطلب مصدر تقديرات مرخّصًا",
    "authorized_market_history_feed_required": "لا يوجد مصدر أسعار تاريخية معتمد يغطي سنة كاملة",
    "authorized_news_feed_required": "لا يوجد مصدر أخبار مرخّص",
    "announcement_feed_not_connected": "لم يُربط مصدر إعلانات تداول بعد",
    "no_sourced_company_attributes": "لا توجد معلومات وصفية موثقة بمصدر",
    "no_sourced_ownership_positions": "لا توجد بيانات ملكية موثقة بمصدر",
    "no_sourced_corporate_actions": "لا توجد إجراءات شركة موثقة بمصدر",
    "no_archived_official_sources": "لا توجد مصادر رسمية مؤرشفة",
    "fewer_than_five_annual_periods": "أقل من خمس سنوات مالية منشورة",
    "no_other_peer_with_comparable_facts": "لا توجد شركة مماثلة ببيانات قابلة للمقارنة",
    "valuation_multiples_not_delivered_in_page": "الأسعار موجودة لكن مضاعفات التقييم لا تصل في العقد بعد",
    "run_factory_contract_readiness": "لم يُشغَّل تقييم الجاهزية للفئات الـ18 بعد",
    "not_disclosed": "لم تفصح عنه الشركة",
    "no_fy_facts": "لا توجد قوائم سنوية منشورة",
    "no_quarter_facts": "لا توجد قوائم ربعية منشورة",
    "no_ytd_facts": "لا توجد بيانات منذ بداية السنة",
    "no_ttm_facts": "لا توجد بيانات آخر 12 شهرًا",
    "no_instant_facts": "لا يوجد مركز مالي منشور",
    "financial_unit_review_required": "تتطلب بعض القيم مراجعة اتساق الوحدة؛ تُعرض القيم المتاحة فقط",
}

CAPABILITY_AR = {
    "profile": "ملف الشركة", "annual_financials": "القوائم السنوية", "quarterly_financials": "القوائم الربعية",
    "market_history": "تاريخ الأسعار", "ownership": "الملكية", "corporate_actions": "إجراءات الشركة",
    "disclosures": "الإفصاحات", "consensus": "تقديرات المحللين", "peer_comparison": "المقارنة",
    "news": "الأخبار", "five_year_history": "تاريخ خمس سنوات", "official_sources": "المصادر الرسمية",
}

PERCENT_RATIO = re.compile(
    r"(margin|^return_on|^roace$|yield|growth|cagr|payout_ratio|tax_rate|^equity_ratio$|^liabilities_to_assets$"
    r"|cost_to_income|loans_to_deposits|nonperforming_loans_ratio|^cost_of_risk$|_to_revenue$|^accrual_ratio$"
    r"|^income_quality$)")
PER_SHARE_KEY = re.compile(r"(_per_share$|^basic_eps$|^eps_diluted$|^earnings_per_share)")
SHARE_COUNT_KEY = re.compile(r"^(weighted_average_shares|shares_outstanding|shares_issued_count)")


def reason_ar(code: str | None) -> str:
    if not code:
        return ""
    if code.startswith("missing:"):
        return ""
    return REASON_AR.get(code, code)


def unit_conflict(key: str, row: dict) -> bool:
    """Same rule as the website: withhold, never correct."""
    unit = row.get("unit") or ""
    if PER_SHARE_KEY.search(key) or (row.get("statement") == "per_share" and not key.endswith("_growth")):
        currency = row.get("currency") or ""
        return (not isinstance(unit, str) or not isinstance(currency, str)
                or re.fullmatch(r"[A-Z]{3}", currency) is None
                or unit != currency + "/share")
    if SHARE_COUNT_KEY.search(key):
        return unit != "shares"
    return False


def _grouped(number: Decimal, digits: int) -> str:
    return f"{number:,.{digits}f}"


def format_value(key: str, value, unit: str, currency: str) -> str | None:
    """Display text for one contract value, or None when there is no value."""
    if value is None:
        return None
    try:
        number = Decimal(str(value))
    except InvalidOperation:
        return str(value)
    currency_ar = {"SAR": "ر.س", "USD": "دولار"}.get(currency, currency)
    if unit == "ratio":
        return f"{_grouped(number * 100, 1)}%" if PERCENT_RATIO.search(key) else f"{_grouped(number, 2)}×"
    if unit == "percent":
        return f"{_grouped(number, 1)}%"
    if currency and unit == currency:
        magnitude = abs(number)
        if magnitude >= Decimal("1e9"):
            return f"{_grouped(number / Decimal('1e9'), 2)} مليار {currency_ar}"
        if magnitude >= Decimal("1e6"):
            return f"{_grouped(number / Decimal('1e6'), 2)} مليون {currency_ar}"
        return f"{_grouped(number, 2)} {currency_ar}"
    if unit.endswith("/share"):
        return f"{_grouped(number, 2)} {currency_ar}/سهم"
    return f"{_grouped(number, 2)} {unit}".strip()


def _consolidated(rows: list[dict] | None) -> dict | None:
    for row in rows or []:
        if row.get("scope") == "consolidated" and not row.get("dimensions"):
            return row
    return None


def _page(query: FinancialQueryService, market: str, symbol: str) -> dict | None:
    try:
        page = query.company_page(market, symbol)
    except KeyError:
        return None
    if page.get("contract_version") != SUPPORTED_CONTRACT_VERSION:
        raise ValueError(f"unsupported page contract {page.get('contract_version')}")
    return page


def _title(page: dict) -> str:
    profile = page["sections"]["profile"]
    name = (profile.get("company_name_ar") or {}).get("value") or page["company"]["name"]
    return f"{name} ({page['company']['market']}:{page['company']['symbol']})"


def _readiness_lines(page: dict) -> list[str]:
    readiness = page["data_quality"]["factory_readiness"]
    return [READINESS_NOTE] if readiness.get("readiness_state") != "ready" else []


def fin_lines(page: dict, kind: str) -> tuple[list[dict], list[str]]:
    """Structured lines for /fin: (shown rows, withheld keys).  Exposed for tests."""
    snapshot = page["sections"]["financials"][KIND_SNAPSHOT[kind]]
    shown, withheld = [], []
    for key in FIN_LINES[kind]:
        row = _consolidated(snapshot["metrics"].get(key))
        if not row:
            continue
        if row.get("quality_status") == "quarantined" or unit_conflict(key, row):
            withheld.append(key)
            continue
        text = format_value(key, row.get("value"), row.get("unit") or "", row.get("currency") or "")
        if text is None:
            continue
        provenance = row.get("provenance") or {}
        source = provenance.get("source") or {}
        derivation = provenance.get("derivation") or {}
        calculated = bool(row.get("is_calculated") or derivation)
        lineage = derivation.get("lineage") or {}
        inputs = lineage.get("consumed_inputs") or []
        reproduced = (lineage.get("current_inputs_reproduced") is True
                      and lineage.get("status") == "reproduced_current_inputs"
                      and bool(inputs))
        if calculated:
            # An output's inherited filing URL is not a source-statement amount.
            source_urls = list(dict.fromkeys(item.get("source_url") for item in inputs
                                             if isinstance(item, dict) and item.get("source_url"))) if reproduced else []
            method = "محسوب؛ أُعيد إنتاجه من مدخلاته المسجلة" if reproduced else "محسوب؛ مدخلاته غير موثقة"
        else:
            source_urls = [source.get("source_url") or row.get("source_url")]
            source_urls = [url for url in source_urls if url]
            method = None
        shown.append({"key": key, "raw": str(row.get("value")), "text": text,
                      "period_kind": row["period_kind"], "period_end": row["period_end"],
                      "source_url": source_urls[0] if source_urls else None,
                      "source_urls": source_urls, "is_calculated": calculated,
                      "lineage_state": lineage.get("status", "not_recorded") if calculated else None,
                      "input_lineage_reproduced": reproduced if calculated else None,
                      "method_label": method})
    return shown, withheld


def answer_fin(page: dict, kind: str) -> str:
    snapshot = page["sections"]["financials"][KIND_SNAPSHOT[kind]]
    head = f"{_title(page)} — {KIND_AR[kind]}"
    if snapshot["status"] not in {"available", "partial"}:
        return f"{head}\nلا توجد بيانات منشورة لهذه الفترة: {reason_ar(snapshot['reason'])}."
    shown, withheld = fin_lines(page, kind)
    lines = [f"{head} {snapshot['period_end']}", *_readiness_lines(page)]
    if snapshot["status"] == "partial":
        lines.append("بيانات جزئية: " + reason_ar(snapshot.get("reason")))
    sources: list[str] = []
    for item in shown:
        for url in item["source_urls"]:
            if url not in sources:
                sources.append(url)
        marker = " ".join(f"[{sources.index(url) + 1}]" for url in item["source_urls"])
        if not marker:
            marker = "[مصادر المدخلات غير موثقة]" if item["is_calculated"] else "[بلا مصدر]"
        method = f" — {item['method_label']}" if item["method_label"] else ""
        lines.append(f"• {LABEL_AR.get(item['key'], item['key'])}: {item['text']} {marker}{method}")
    if not shown:
        lines.append("لا توجد بنود رئيسية منشورة لهذه الفترة.")
    if withheld:
        lines.append("محجوب لعدم اتساق الوحدة في المصدر: " + "، ".join(LABEL_AR.get(k, k) for k in withheld))
    lines += [f"[{index}] {url}" for index, url in enumerate(sources, start=1)]
    return "\n".join(lines)


def answer_topics(page: dict) -> str:
    lines = [f"{_title(page)} — موضوعات المستثمر الـ18", *_readiness_lines(page)]
    for topic in assess(page, load_contract_gaps()):
        reasons = [reason_ar(code) for code in topic["reasons"]]
        reasons = [reason for reason in reasons if reason]
        if topic["state"] != "available" and not reasons:
            reasons = ["لا تصل بيانات هذا الموضوع في رد الواجهة بعد"]
        suffix = f" — {reasons[0]}" if reasons else ""
        lines.append(f"{STATE_MARK[topic['state']]} {topic['name_ar']}: {STATE_AR[topic['state']]}{suffix}")
    return "\n".join(lines)


def answer_missing(page: dict) -> str:
    lines = [f"{_title(page)} — ما الناقص ولماذا"]
    completeness = page["data_quality"]["completeness"]
    if completeness.get("status") == "assessed" and completeness.get("completeness_score") is not None:
        share = Decimal(completeness["completeness_score"]) * 100
        lines.append(f"تغطية الحقول: {_grouped(share, 1)}% ({completeness['populated_fields']} من "
                     f"{completeness['expected_fields']})")
    else:
        lines.append("تغطية الحقول: غير مُقاسة")
    for key, capability in page["capabilities"].items():
        if capability["status"] != "available":
            state = STATE_AR.get(capability["status"], capability["status"])
            label = CAPABILITY_AR.get(key, key)
            lines.append(f"• {label}: {state} — {reason_ar(capability.get('reason')) or 'بلا سبب من الواجهة'}")
    for item in page["data_quality"]["field_availability"]:
        expired = "" if item.get("evidence_current", True) else " (الدليل منتهي الصلاحية)"
        lines.append(f"• {item['field_key']}: {reason_ar(item['reason_code'])}{expired} — {item['evidence_url']}")
    withheld = []
    for kind in ("annual", "instant", "quarter"):
        for key, rows in page["sections"]["financials"][kind]["metrics"].items():
            row = _consolidated(rows)
            if row and (row.get("quality_status") == "quarantined" or unit_conflict(key, row)) and key not in withheld:
                withheld.append(key)
    if withheld:
        lines.append("قيم محجوبة لعدم اتساق الوحدة (أُبلغ عنها لفريق المحرك): " + "، ".join(withheld))
    return "\n".join(lines)


def answer_sources(page: dict, limit: int = 10) -> str:
    sources = page["sections"]["official_sources"]
    if not sources:
        return f"{_title(page)}\nلا توجد مصادر رسمية مؤرشفة."
    lines = [f"{_title(page)} — المصادر الرسمية ({min(limit, len(sources))} من {len(sources)})"]
    for item in sources[:limit]:
        lines.append(f"• {item.get('filed_at') or '—'} {item.get('filing_type') or item['source_key']}\n  "
                     f"{item.get('source_url') or 'بلا رابط'}")
    return "\n".join(lines)


def answer(db_path: str, text: str) -> str:
    parts = text.strip().split()
    command = parts[0].split("@", 1)[0].lower() if parts else "/help"
    if command in {"/start", "/help"}:
        return HELP
    handlers = {"/topics": 3, "/fin": (3, 4), "/missing": 3, "/sources": 3}
    if command not in handlers:
        return engine_answer(db_path, text)
    sizes = handlers[command] if isinstance(handlers[command], tuple) else (handlers[command],)
    if len(parts) not in sizes:
        return HELP
    query = FinancialQueryService(db_path)
    try:
        page = _page(query, parts[1], parts[2])
        if page is None:
            return f"{parts[1].upper()}:{parts[2].upper()}\n{NOT_COVERED}"
        if command == "/topics":
            return answer_topics(page)
        if command == "/missing":
            return answer_missing(page)
        if command == "/sources":
            return answer_sources(page)
        kind = parts[3].lower() if len(parts) == 4 else "fy"
        if kind not in KIND_SNAPSHOT:
            return "الفترة يجب أن تكون fy أو quarter أو instant."
        return answer_fin(page, kind)
    except ValueError as error:
        return f"تعذر تنفيذ الطلب: {error}"
    finally:
        query.close()
