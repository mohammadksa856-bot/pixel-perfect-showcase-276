"""The 18 investor topics, mapped onto the public company-page contract (v5).

This is the product-side source of truth for "which part of the API answers
which investor question".  It reads only the page payload an external consumer
receives (``/v1/companies/{m}/{s}/page``); it never queries the database and
never derives a value.  For every topic it reports:

* ``state``     -- available | partial | unavailable | not_in_contract
* ``delivered`` -- what the page actually carries for the topic (counts/keys)
* ``reasons``   -- the API's own reasons when something is missing
* ``contract_gaps`` -- investor fields with no catalog field / storage today
  (from docs/claude_integration/consumer_delivery_crosswalk.json)

``python product/investor_topics.py --write`` regenerates
``product/investor_topic_map.json`` (the map the website and bot mirror) and a
per-company gap report for every page in ``product/demo``.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CROSSWALK = ROOT / "docs" / "claude_integration" / "consumer_delivery_crosswalk.json"
MAP_OUTPUT = ROOT / "product" / "investor_topic_map.json"
DEMO = ROOT / "product" / "demo"
MAP_VERSION = 1
PERIOD_KINDS = ("annual", "quarter", "ytd", "ttm", "instant")

# Statement groups from metric_definitions.statement.  Sector packs report their
# primary lines and KPIs under their own groups (banking_*, insurance_*, *_operations).
INCOME_STATEMENTS = ("income_statement", "banking_income", "insurance_income")
SECTOR_KPI_STATEMENTS = (
    "operational", "production", "reliability", "market_driver", "capacity", "reserves", "commercial",
    "banking_balance_sheet", "banking_ratios", "insurance_balance_sheet", "insurance_ratios",
    "asset_management_operations", "food_agriculture_operations", "healthcare_operations",
    "industrial_operations", "mining_operations", "real_estate_operations", "retail_operations",
    "technology_operations", "telecom_operations", "transport_operations", "utilities_operations",
)

# Each source is (kind, argument).  ``core`` sources must all be present for a
# topic to be "available"; ``extra`` sources only add depth.
#   company    -> keys in the company registry block (page["company"])
#   profile    -> keys in sections.profile (sourced company attributes)
#   statement  -> data-point ``statement`` values in sections.financials.*
#   metric     -> explicit metric keys in sections.financials.*
#   metric_pattern -> metric keys containing any of the substrings
#   section    -> non-empty list section (ownership, corporate_actions, ...)
#   disclosure -> disclosure_type values in sections.disclosures
#   market     -> sections.market.latest present
#   peers      -> peer_comparison with at least one other company
#   history    -> sections.financials.history.<name> has periods
TOPICS: dict[str, dict] = {
    "identity": {"core": [("company", ("name", "exchange", "sector", "currency", "fiscal_year_end"))],
                 "extra": [("company", ("isin",)),
                           ("profile", ("legal_name", "listing_date", "legal_form", "headquarters_address"))],
                 "capability": "profile"},
    "business": {"core": [("profile", ("business_description",))],
                 "extra": [("profile", ("business_segments", "products_services", "geographic_presence")),
                           ("statement", ("segments",))],
                 "capability": "profile"},
    "governance": {"core": [("profile", ("ceo_name", "chairman_name"))],
                   "extra": [("profile", ("auditor",))], "capability": "profile"},
    "ownership": {"core": [("section", "ownership")], "capability": "ownership"},
    "financials": {"core": [("statement", INCOME_STATEMENTS), ("statement", ("cash_flow",)),
                            ("metric", ("total_assets", "total_equity"))],
                   "extra": [("history", "annual"), ("history", "quarter"), ("statement", ("financial_notes",))],
                   "capability": "annual_financials"},
    "earnings_quality": {"core": [("statement", ("analytics",))], "capability": "annual_financials"},
    "ratios": {"core": [("statement", ("ratios",))], "extra": [("statement", ("growth",))],
               "capability": "annual_financials"},
    "operations": {"core": [("statement", SECTOR_KPI_STATEMENTS)], "capability": "annual_financials"},
    "dividends_actions": {"core": [("metric", ("dividends_per_share",))],
                          "extra": [("statement", ("dividends",)), ("section", "corporate_actions")],
                          "capability": "corporate_actions"},
    "industry": {"core": [("company", ("sector", "industry"))], "extra": [("profile", ("sub_industry",))],
                 "capability": "profile"},
    "competitors": {"core": [("peers", None)], "capability": "peer_comparison"},
    "trading": {"core": [("market", None)], "capability": "market_history"},
    # Issuer guidance is a disclosure; analyst consensus only adds depth.
    "forecasts": {"core": [("disclosure", ("guidance",))], "extra": [("section", "consensus")],
                  "capability": "disclosures"},
    "analysts": {"core": [("section", "consensus")], "capability": "consensus"},
    "valuation": {"core": [("statement", ("valuation",))], "capability": "market_history",
                  "missing_reason": "valuation_multiples_not_delivered_in_page"},
    # Same disclosure types finengine.understanding counts as risk evidence.
    "risks": {"core": [("disclosure", ("risk_factor", "risk_disclosure", "risk_management", "liquidity_risk",
                                       "contingency", "customer_concentration", "restatement"))],
              "extra": [("profile", ("credit_rating",))], "capability": "disclosures"},
    # Same metric-key patterns finengine.understanding counts as ESG evidence.
    "esg": {"core": [("metric_pattern", ("emission", "water", "saudization", "injury", "sustainab"))],
            "capability": "disclosures"},
    "news": {"core": [("disclosure", ("press_coverage", "official_announcement"))],
             "extra": [("disclosure", ("interim_report", "annual_report"))], "capability": "news"},
}

# Topics whose core source is a licensed feed the platform does not hold.
LICENSED = {"analysts": "licensed_consensus_feed_required"}


def _metrics(page: dict) -> dict[str, dict]:
    """metric key -> first row, across every period-kind snapshot."""
    found: dict[str, dict] = {}
    for kind in PERIOD_KINDS:
        snapshot = page["sections"]["financials"].get(kind) or {}
        for key, rows in (snapshot.get("metrics") or {}).items():
            eligible = next((row for row in rows if row.get("value") is not None
                             and row.get("quality_status") != "quarantined"), None)
            if eligible is not None and key not in found:
                found[key] = eligible
    return found


def _resolve(page: dict, metrics: dict[str, dict], kind: str, arg) -> list[str]:
    """Return the evidence keys the page carries for one source (empty = absent)."""
    sections = page["sections"]
    if kind == "company":
        return [key for key in arg if page["company"].get(key)]
    if kind == "profile":
        return [key for key in arg if key in sections["profile"]]
    if kind == "statement":
        return sorted(key for key, row in metrics.items() if row.get("statement") in arg)
    if kind == "metric":
        return [key for key in arg if key in metrics]
    if kind == "metric_pattern":
        return sorted(key for key in metrics if any(part in key for part in arg))
    if kind == "section":
        return [f"{arg}:{len(sections[arg])}"] if sections.get(arg) else []
    if kind == "disclosure":
        hits = [item["disclosure_type"] for item in sections["disclosures"] if item["disclosure_type"] in arg]
        return [f"{name}:{hits.count(name)}" for name in sorted(set(hits))]
    if kind == "market":
        return ["market:latest"] if sections["market"].get("latest") else []
    if kind == "peers":
        peers = sections["peer_comparison"]
        return [f"peers:{peers['peer_count']}"] if peers.get("peer_count") else []
    if kind == "history":
        history = sections["financials"]["history"].get(arg) or {}
        return [f"history.{arg}:{len(history.get('periods', []))}"] if history.get("periods") else []
    raise ValueError(f"unknown source kind {kind}")


def _verification(rows: list[dict]) -> dict[str, int]:
    """Count values by how the contract says they were produced -- never upgraded."""
    counts: dict[str, int] = {}
    for row in rows:
        derivation = (row.get("provenance") or {}).get("derivation")
        if row.get("is_calculated") or derivation:
            state = f"calculated_{((derivation or {}).get('lineage') or {}).get('status', 'not_recorded')}"
        elif (row.get("provenance") or {}).get("extraction"):
            state = "reported_extracted"
        else:
            state = "reported_manifest"
        counts[state] = counts.get(state, 0) + 1
    return dict(sorted(counts.items()))


def load_contract_gaps() -> dict[str, dict]:
    crosswalk = json.loads(CROSSWALK.read_text(encoding="utf-8"))
    return {topic["topic_key"]: {"name_ar": topic["name_ar"], "name_en": topic["name_en"],
                                 "investor_fields_total": topic["investor_fields_total"],
                                 "not_in_catalog": topic["not_in_catalog"], "rights": topic["rights"]}
            for topic in crosswalk["investor_topics"]}


def assess(page: dict, gaps: dict[str, dict] | None = None) -> list[dict]:
    """Grade every investor topic on one company page payload."""
    gaps = gaps if gaps is not None else load_contract_gaps()
    metrics = _metrics(page)
    capabilities = page["capabilities"]
    result = []
    for key, spec in TOPICS.items():
        core = [_resolve(page, metrics, kind, arg) for kind, arg in spec["core"]]
        extra = [_resolve(page, metrics, kind, arg) for kind, arg in spec.get("extra", [])]
        delivered = sorted({item for hits in core + extra for item in hits})
        if key in LICENSED and not delivered:
            state = "not_in_contract"
        elif all(core):
            state = "available"
        elif delivered:
            state = "partial"
        else:
            state = "unavailable"
        capability = capabilities.get(spec["capability"], {})
        # The API's own capability verdict caps the topic: stored items without the
        # feed behind them (news, a few weeks of prices) are never "available".
        if state == "available" and capability.get("status") == "partial":
            state = "partial"
        elif state == "available" and capability.get("status") == "unavailable":
            # Preserve stored evidence but never upgrade the API's absence verdict.
            state = "partial" if delivered else "unavailable"
        reasons = []
        if state != "available":
            if key in LICENSED:
                reasons.append(LICENSED[key])
            # A topic-specific reason wins while the capability itself has data
            # (e.g. prices exist but no multiples); otherwise cite the API's reason.
            if spec.get("missing_reason") and capability.get("status") != "unavailable":
                reasons.append(spec["missing_reason"])
            elif capability.get("status") != "available" and capability.get("reason"):
                reasons.append(capability["reason"])
            reasons += [f"missing:{kind}" + (f":{','.join(arg)}" if isinstance(arg, tuple) and len(arg) <= 6
                                             else f":{arg}" if isinstance(arg, str) else "")
                        for (kind, arg), hits in zip(spec["core"], core) if not hits]
        topic_rows = [metrics[name] for name in delivered if name in metrics]
        info = gaps.get(key, {})
        result.append({
            "topic_key": key, "name_ar": info.get("name_ar"), "state": state,
            "delivered": delivered, "reasons": list(dict.fromkeys(reasons)),
            "verification": _verification(topic_rows),
            "contract_gaps": info.get("not_in_catalog", []), "rights": info.get("rights"),
        })
    return result


def topic_map() -> dict:
    gaps = load_contract_gaps()
    return {
        "artifact": "investor_topic_map", "map_version": MAP_VERSION, "page_contract_version": 5,
        "states": ["available", "partial", "unavailable", "not_in_contract"],
        "topics": [{"topic_key": key, **gaps[key],
                    "core_sources": [[kind, list(arg) if isinstance(arg, tuple) else arg] for kind, arg in spec["core"]],
                    "extra_sources": [[kind, list(arg) if isinstance(arg, tuple) else arg]
                                      for kind, arg in spec.get("extra", [])],
                    "capability": spec["capability"], "licensed_reason": LICENSED.get(key),
                    "missing_reason": spec.get("missing_reason")}
                   for key, spec in TOPICS.items()],
    }


def _dump(payload) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=1) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Investor topic map and demo gap reports")
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    outputs = {MAP_OUTPUT: _dump(topic_map())}
    gaps = load_contract_gaps()
    for page_file in sorted(DEMO.glob("*-page.json")):
        page = json.loads(page_file.read_text(encoding="utf-8"))
        if "sections" not in page:
            continue
        report = {"company": f"{page['company']['market']}:{page['company']['symbol']}",
                  "page_generated_at": page["generated_at"], "topics": assess(page, gaps)}
        outputs[page_file.with_name(page_file.name.replace("-page.json", "-topics.json"))] = _dump(report)
    for path, text in outputs.items():
        if args.write:
            path.write_text(text, encoding="utf-8", newline="\n")
        print(path.relative_to(ROOT).as_posix(), len(text))


if __name__ == "__main__":
    main()
