"""Admit immutable GitHub delivery references, not foreign ledger copies."""
import hashlib
import json
from pathlib import Path
import subprocess

from .project_tracking import BOARD, _immutable, fingerprint, load

REPOSITORY = "mohammadksa856-bot/pixel-perfect-showcase-276"
LEDGER = "product-tracking/CHANGELOG.jsonl"
STATUS = "product-tracking/TRACK_STATUS.json"


def git_blob(repo, commit, path):
    return subprocess.check_output(["git", "cat-file", "blob", commit + ":" + path], cwd=repo)


def admit(root, repo, commit, *, source_branch='main-fz2efq', report_names=None):
    root = Path(root)
    ledger = git_blob(repo, commit, LEDGER)
    status_raw = git_blob(repo, commit, STATUS)
    events = [json.loads(line) for line in ledger.splitlines() if line.strip()]
    status = json.loads(status_raw)
    namespace = hashlib.sha256((REPOSITORY + ":" + LEDGER).encode()).hexdigest()[:16]
    old = [load(p) for p in (root / "docs/tracking/external_events").glob("*.json")]
    prefix = {item["external_id"]: item for item in old if item["external_id"].startswith(namespace + ":")}
    if any(item["source_event_sequence"] > len(events) for item in prefix.values()):
        raise ValueError("Remote sender ledger was truncated")
    pending = []
    runs = {run["id"]: run for run in status.get("test_runs", [])}
    for index, event in enumerate(events, 1):
        identity = namespace + ":" + str(index)
        digest = fingerprint(event)
        if identity in prefix:
            if prefix[identity]["source_event_sha256"] != digest:
                raise ValueError("Remote sender history changed")
            continue
        if not {"task", "event", "ts"} <= set(event):
            raise ValueError("Invalid remote ledger event")
        pending.append(dict(external_id=identity, source_event_sha256=digest,
                            source_event_sequence=index, sequence_basis="derived_line_order_not_sender_seq",
                            source_actor_claim=None, source_repository="https://github.com/" + REPOSITORY,
                            source_path=LEDGER, source_branch=source_branch, source_commit=event.get("commit"),
                            reviewed_source_head=commit, source_at=event["ts"], claim_type=event["event"],
                            sender_task_id=event["task"], central_task_id="P01-15" if event["task"] == "P01-15" else "R02" if event["task"] == "R02" else "P01",
                            source_ledger_sha256=hashlib.sha256(ledger).hexdigest(),
                            referenced_runs=[dict(runs[event["run"]], verification="sender_reported_not_rerun")] if event.get("run") in runs else [],
                            review_state="ADMITTED_AS_REMOTE_EVIDENCE_ONLY", raw_event_copied=False,
                            code_accepted=False, tests_verified_here=False, integrated=False,
                            product_accepted=False, production_published=False))
    # Validate the full prefix before adding any receipt; never rewrite old evidence.
    for item in pending:
        _immutable(root / "docs/tracking/external_events" / (item["external_id"].replace(":", "-") + ".json"), item)
    reports = []
    for name in (report_names or ("BR-003.md", "BR-004.md", "P01-15_peer_comparison.md")):
        path = "product-tracking/reports/" + name
        raw = git_blob(repo, commit, path)
        digest = hashlib.sha256(raw).hexdigest()
        reference = "docs/tracking/external_reports/" + digest + ".json"
        receipt = dict(source_report_id=name, source_sha256=digest,
                                        source_path=path, source_repository=REPOSITORY,
                                        source_url="https://github.com/" + REPOSITORY + "/blob/" + commit + "/" + path,
                                        reviewed_source_head=commit, source_branch=source_branch,
                                        raw_report_copied=False, central_disposition="Sender evidence only; no independent financial accuracy or product acceptance")
        if not (root / reference).exists():
            _immutable(root / reference, receipt)
        reports.append(reference)
    board = load(root / BOARD)
    by_id = {t["id"]: t for t in board["tasks"]}
    definitions = {
        "P01-15": dict(description="Claude peer comparison: code review and pending company page wiring", owner="Claude Code", dependencies=["P01", "R02"], parent_task_id="P01"),
        "O02": dict(description="Fail-closed staging/production API startup authentication", owner="Codex", dependencies=["B03"], parent_task_id="O01")}
    for task_id, definition in definitions.items():
        if task_id not in by_id:
            task = dict(id=task_id, **definition, priority=0, state="REVIEW", branch="main-fz2efq" if task_id == "P01-15" else "integration/engine-product-20261012",
                        commits=[], changed_files=[], test_runs=[], evidence=[], blockers=[], required_decisions=[],
                        change_stage="LOCAL_REVIEW", production_published=False)
            board["tasks"].append(task)
            by_id[task_id] = task
    for path in (root / "docs/tracking/external_events").glob("*.json"):
        item = load(path)
        if not item["external_id"].startswith(namespace + ":"):
            continue
        refs = by_id[item["central_task_id"]].setdefault("external_evidence", [])
        reference = path.relative_to(root).as_posix()
        if reference not in refs:
            refs.append(reference)
            refs.sort()
    result = dict(source_head=commit, source_repository=REPOSITORY, source_branch=source_branch,
                  ledger_sha256=hashlib.sha256(ledger).hexdigest(), status_sha256=hashlib.sha256(status_raw).hexdigest(),
                  new_events=len(pending), events_seen=len(events), report_refs=reports,
                  original_sender_writes=0, raw_ledger_copied=False, automatic_acceptance=False)
    board["execution_tracking"]["latest_Claude_cloud_admission"] = result
    (root / BOARD).write_text(json.dumps(board, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result
